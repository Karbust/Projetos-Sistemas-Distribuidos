package harreader;

public class HarReaderException extends Exception {

    public HarReaderException(Throwable cause) {
        super(cause);
    }

}
