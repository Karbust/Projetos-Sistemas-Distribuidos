public class ProcessCombinationModel {
    public String combination;
    public int numberOfRuns=0;
    public long resourceLength=0;
    public float percentage;
}
